package com.company;
import java.util.Scanner;
public class Main {

    public static int getFactorial(int f) {
        int result = 1;
        for (int i = 1; i <= f; i++) {
            result = result * i;
        }
        return result;
    }
    public static void main(String[] arg) {
        int x = 0;
        double b = 1;
        double sum = 0;
        System.out.println("\n" + "2 mission" +
                "\n");

        for (int i = 1; i <= 10; i++) {
            b = (double) 1 / i;
            sum += b;
            System.out.println(b);
        }

        System.out.println(sum);
        System.out.println("\n" + "3 mission" +
                "\n");
        int[] array = new int[10];
        for (int i = 0; i < array.length; i++) {
            array[i] = (int) (Math.random() * 100);
            System.out.println(array[i]);
        }
        for (int j = 0; j < array.length; j++) {
            for (int i = 0; i < array.length - 1; i++) {
                if (array[i] > array[i + 1]) {
                    x = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = x;
                }
            }
        }

        System.out.println("\n");
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }
        System.out.println("write a number");
        Scanner sc = new Scanner(System.in);
        int f = sc.nextInt();
        sc.close();
        System.out.println("mission4" + "\n" + " factorial of " + f + " = " + getFactorial(f));


    }
}
